#include <sys/types.h>

unsigned short CalculaChecksum(unsigned short *addr, int len);
void MontarHeaderIp(char* ipDestino, int tamanhoMensagem);
