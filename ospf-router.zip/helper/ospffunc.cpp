

void MontarHeaderOspf(int tipo, int tamanhoMensagem)
{
	ospf.type = tipo;
	ospCSDbd.type = ospf.type;
	ospf.len = htons(sizeof(ospf) + tamanhoMensagem);

	ospCSDbd.len = ospf.len;
	ospCSLsu.len = ospf.len;
	lsuAck.len = ospf.len;
}

void MontarDadosPadraoMensagem(MacAddress mac_L, MacAddress mac_D)
{
	memcpy(buffer, mac_D, MAC_ADDR_LEN);
	memcpy((buffer + MAC_ADDR_LEN), mac_L, MAC_ADDR_LEN);
	memcpy((buffer + (2 * MAC_ADDR_LEN)), &(etherTypeT), sizeof(etherTypeT));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT), &ipHeader, IP4_HDRLEN);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN, &ospf, sizeof(ospf));
}

void EnviaMensagemHello(MacAddress mac_L, MacAddress mac_D, int primeiraMensagem)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipMulticast, sizeof(hello));
	MontarHeaderOspf(1, sizeof(hello));

	// Configuração pacote Hello
	inet_pton (AF_INET, ipBroadcast, &(hello.mask));
	hello.helloint = htons(10);
	hello.options = 18;
	hello.priority = 1;
	hello.deadint = ntohl(40);

    // Na primeria mensagem não há roteador backup
	if(primeiraMensagem)
	{
		inet_pton (AF_INET, "0.0.0.0", &(hello.dr));
		inet_pton (AF_INET, "0.0.0.0", &(hello.bdr));
	}
	else
	{
		inet_pton (AF_INET, ipRoteador, &(hello.dr));
		inet_pton (AF_INET, ipLocal, &(hello.bdr));
	}
	inet_pton (AF_INET, ipRoteador, &(hello.neighbor[0]));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &hello, sizeof(hello));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(hello), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + sizeof(llsHeader) + IP4_HDRLEN + sizeof(ospf) + sizeof(hello),
		0, (struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Hello - Erro! \n");
		exit(1);
	}

	printf("Mensagem Hello - %d\n", retornoEnvio);
}

void EnviaMensagemDbd(MacAddress mac_L, MacAddress mac_D, int dbDescription)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipRoteador, sizeof(dbdHeader));
	MontarHeaderOspf(2, sizeof(dbdHeader));

	// Configuração pacote Bdb
	dbdHeader.ddsequence = htonl(seqDbScript);
	dbdHeader.dbdescript = dbDescription;

	seqDbScript++;

	ospCSDbd.ddsequence = dbdHeader.ddsequence;
	ospCSDbd.dbdescript = dbdHeader.dbdescript;

	ospf.chksum = CalculaChecksum ((uint16_t *) &ospCSDbd, sizeof(ospCSDbd));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &dbdHeader, sizeof(dbdHeader));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(dbdHeader), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + sizeof(llsHeader) + IP4_HDRLEN + sizeof(ospf) + sizeof(dbdHeader), 0,
		(struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Bdb - Erro! \n");
		exit(1);
	}

	printf("Mensagem Dbd - %d\n", retornoEnvio);
}


void EnviaMensagemLsuRouter(MacAddress mac_L, MacAddress mac_D)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipRoteador, sizeof(lsuHeaderRouter));
	MontarHeaderOspf(4, sizeof(lsuHeaderRouter));

    lsuHeaderRouter.lsaRouter.seq = htonl(seqDbScript); // incrementar
    lsuHeaderRouter.lsaRouter.chksum = htons(0); // vai saber

	seqDbScript;


	ospf.chksum = 0xefdd;//CalculaChecksum ((uint16_t *) &ospCSLsu, sizeof(ospCSLsu));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &lsuHeaderRouter, sizeof(lsuHeaderRouter));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeaderRouter), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeaderRouter) + sizeof(llsHeader), 0,
		(struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Lsu - Erro! \n");
		exit(1);
	}

	printf("-----------------------Mensagem Lsu Router------------------------ %d\n", retornoEnvio);
}
void EnviaMensagemLsuNetwork(MacAddress mac_L, MacAddress mac_D)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipRoteador, sizeof(lsuHeader));
	MontarHeaderOspf(4, sizeof(lsuHeader));

    /*lsuHeader.lsaRouter.seq = htonl(seqDbScript); // incrementar
    lsuHeader.lsaRouter.chksum = htons(0); // vai saber*/

	seqDbScript++;

    lsuHeader.lsaNetw.seq = htonl(seqDbScript); // incrementar
    lsuHeader.lsaNetw.chksum = htons(0); // vai saber

	seqDbScript++;

    ospCSLsu.lsaNetw.seq = lsuHeader.lsaNetw.seq; // incrementar
    ospCSLsu.lsaNetw.chksum = lsuHeader.lsaNetw.chksum; // vai saber

	ospf.chksum = 0xf7e2;//CalculaChecksum ((uint16_t *) &ospCSLsu, sizeof(ospCSLsu));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &lsuHeader, sizeof(lsuHeader));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeader), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeader) + sizeof(llsHeader), 0,
		(struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Lsu - Erro! \n");
		exit(1);
	}

	printf("-----------------------Mensagem Lsu Network------------------------ %d\n", retornoEnvio);
}

void EnviaMensagemLsuInjection(MacAddress mac_L, MacAddress mac_D)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipRoteador, sizeof(lsuHeaderInjection));
	MontarHeaderOspf(4, sizeof(lsuHeaderInjection));

    /*lsuHeader.lsaRouter.seq = htonl(seqDbScript); // incrementar
    lsuHeader.lsaRouter.chksum = htons(0); // vai saber*/

	seqDbScript++;

    lsuHeaderInjection.lsaNetw.seq = htonl(seqDbScript); // incrementar
    lsuHeaderInjection.lsaNetw.chksum = htons(0); // vai saber

	seqDbScript++;

    ospCSLsu.lsaNetw.seq = lsuHeaderInjection.lsaNetw.seq; // incrementar
    ospCSLsu.lsaNetw.chksum = lsuHeaderInjection.lsaNetw.chksum; // vai saber

	ospf.chksum = 0xf7e2;//CalculaChecksum ((uint16_t *) &ospCSLsu, sizeof(ospCSLsu));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &lsuHeaderInjection, sizeof(lsuHeaderInjection));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeaderInjection), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuHeaderInjection) + sizeof(llsHeader), 0,
		(struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Lsu - Erro! \n");
		exit(1);
	}

	printf("-----------------------Mensagem Lsu Network------------------------ %d\n", retornoEnvio);
}

void EnviaMensagemLsuAck(MacAddress mac_L, MacAddress mac_D)
{
	memcpy(&(destAddr.sll_addr), mac_D, MAC_ADDR_LEN);

	MontarHeaderIp(ipRoteador, sizeof(lsuAck));
	MontarHeaderOspf(5, sizeof(lsuAck));

    lsuAck.chksum = htons(0); // vai saber
    lsuAckCs.chksumLSA = htons(0); // vai saber

	//seqDbScript++;
    lsuAck.seq = seqAtual;
    lsuAckCs.seq = seqAtual;

	ospf.chksum = CalculaChecksum ((uint16_t *) &lsuAckCs, sizeof(lsuAckCs));

	MontarDadosPadraoMensagem(mac_L, mac_D);
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf), &lsuAck, sizeof(lsuAck));
	memcpy((buffer + (2 * MAC_ADDR_LEN)) + sizeof(etherTypeT) + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuAck), &llsHeader, sizeof(llsHeader));

	// Envio da mensagem
	if((retornoEnvio = sendto(socketEnvio, buffer, 14 + IP4_HDRLEN + sizeof(ospf) + sizeof(lsuAck) + sizeof(llsHeader), 0,
		(struct sockaddr *)&(destAddr), sizeof(struct sockaddr_ll))) < 0)
	{
		printf("Mensagem Lsu - Erro! \n");
		exit(1);
	}

	printf("-----------------------Mensagem Lsu--------------------- - %d\n", retornoEnvio);
}
